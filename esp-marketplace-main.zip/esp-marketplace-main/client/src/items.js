const items = [
    {
        id: 1,
        price: 250,
        name: "Queen Upholstered Panel Bed With Storage",
        condition: "fairly new",
        ph: 4083882992,
        address: "Q401 Patricia St, Jasper, Alberta, T0E 1E0",
        url: "https://encrypted-tbn1.gstatic.com/shopping?q=tbn:ANd9GcTXi0Urk0eP47-hM-zH90y42Uradc8pt9kw4M_VGmDfz5X3UDoNNIVS5YaVUkPXvCORJDylLS_y0A&usqp=CAc",
        saved: false
    },
    {
        id: 2,
        price: 30,
        name: "Walmart portable closet",
        condition: "used",
        ph: 9928002333,
        address: "Q401 Morgan St, Jasper, Queens, T0E 1E0",
        url: "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcTaVoiJboVkgHa1BEJ9nvItrzlUT8YZZC2qaXrDu9YwMC_rwOvC3Oft6abETy0KPgTsOLVXVXx0ng&usqp=CAc",
        saved: true
    },
    {
        id: 3,
        price: 30,
        name: "Combed ceramic table lamp",
        condition: "new",
        ph: 4083882992,
        address: "Q401 Patricia St, Jasper, Alberta, T0E 1E0",
        url: "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcRTkoJh65sXft2TgGmTBClrOzX63CXYqrx7yPoWGn_kap-w7WcqZX6uAJ1pN6JxckWf3oinAHaOLDlJO6OBcgFlhe4uSblDQ7xapSQi9FU&usqp=CAc",
        saved: false
    },
    {
        id: 4,
        price: 15,
        name: "Baking plates",
        condition: "Fairly new",
        ph: 4083882992,
        address: "Q1 Andreah St, Jasper, Georgia, T0E 1E0",
        url: "https://encrypted-tbn2.gstatic.com/shopping?q=tbn:ANd9GcQDbn6NJBUIwOXpAcjWeBF2_s7oD7HKoAyFLmeaaL0nvs7lEmWnyei_oemp5bKO7QkRQb4huv-06Q&usqp=CAc",
        saved: true
    }
]

export default items;